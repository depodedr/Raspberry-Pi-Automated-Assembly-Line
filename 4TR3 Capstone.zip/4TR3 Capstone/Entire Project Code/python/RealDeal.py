import numpy as np
#import matplotlib.pyplot as plt
import cv2
import time

from PerspectiveRotation import *
from ImageRec import *
from Contour import *
from RigidTranform import *
from camera import *



def EntireImageRecognitionSection():

	font = cv2.FONT_HERSHEY_SIMPLEX

	unsortedanswers =[]
	failure=[]

	takePhoto(10,"cutoff.jpg")
	print("First photo taken, scatter pieces now!!!")

	time.sleep(1)

	takePhoto(70,"pieces.jpg")

	# This automatically grabs the frame of the completed puzzle. output = fullgrey
	full = cv2.imread('/home/pi/Desktop/python/photos/cutoff.jpg')
	fullgrey = cv2.cvtColor(full,cv2.COLOR_BGR2GRAY)
	fullcont = findContours(fullgrey,150000,180000) #These min max values might have to be adjusted
	print("this is: "+str(fullcont[0]))
	rect = cv2.minAreaRect(fullcont[0])
	print("rect is: " + str(rect))
	box = cv2.boxPoints(rect)
	fullgrey = rotatePerspective(fullgrey,box[1],box[2],box[0],box[3])
	cv2.imwrite("cutout.jpg",fullgrey)
	cv2.imshow("show",fullgrey)
	cv2.waitKey(0)
	fullgrey = fullgrey[7:400, 7:400]

	cv2.imshow("show2",fullgrey)
	cv2.waitKey(0)



	scatterpcs = cv2.imread('/home/pi/Desktop/python/photos/pieces.jpg')
	scatterpcsgrey = cv2.cvtColor(scatterpcs,cv2.COLOR_BGR2GRAY)

	contours = findContours(scatterpcsgrey,14000,25000) #These min max values might have to be adjusted

	for index,cnt in enumerate(contours):

		print("piece # "+str(index))

		M = cv2.moments(cnt)
		cx = int(M['m10'] / M['m00'])
		centerx.append(cx)
		cy = int(M['m01'] / M['m00'])
		centery.append(cy)

		rect = cv2.minAreaRect(cnt)
		box = cv2.boxPoints(rect)
		box = np.int0(box)

		W = rect[1][0]
		H = rect[1][1]

		Xs = [i[0] for i in box]
		Ys = [i[1] for i in box]
		x1 = min(Xs)
		x2 = max(Xs)
		y1 = min(Ys)
		y2 = max(Ys)

		rotated = False
		angle = rect[2]
		print("the angle is:" + str(angle))

		if angle < -45:
			angle += 90
			print("the new angle is: " + str(angle))
			rotated = True

		center = (int((x1 + x2) / 2), int((y1 + y2) / 2))
		size = (int(x2 - x1)), int((y2 - y1))

		M = cv2.getRotationMatrix2D((size[0] / 2, size[1] / 2), angle, 1.0)

		cropped = cv2.getRectSubPix(scatterpcsgrey, size, center)
		#cv2.imwrite("pieceC" + str(index) + ".jpg", cropped)

		croppedRotated = cv2.warpAffine(cropped, M, size)
		#cv2.imwrite("pieceCR" + str(index) + ".jpg", cropped)

		croppedW = W if not rotated else H
		croppedH = H if not rotated else W

		croppedRotatedResized = cv2.getRectSubPix(croppedRotated, (int(croppedW), int(croppedH)),
									 (int(croppedW) / 2, int(croppedH) / 2))


		cv2.imwrite("pieceCRresize"+str(index)+".jpg",croppedRotatedResized)

		cv2.circle(scatterpcs, (cx, cy), 5, (0, 0, 255), 2)
		#cv2.putText(scatterpcs, str(cv2.contourArea(cnt)), (cx,cy), font, 1, (0,255,255), 3) #prints the area
		
		combined, pcs_pts, full_pts, totalvote = imageRec(cropped, fullgrey)
		if (totalvote == 10):
			print("FAILED")
			cv2.putText(croppedRotatedResized, "FAILED", (int(int(croppedW) / 2), int(int(croppedH) / 2)),font,0.5,(0,0,255),2)
			cv2.imshow("compare",croppedRotatedResized)
			cv2.waitKey(0)
		else:
			#cv2.imshow("croppedRotated",croppedRotatedResized)
			#cv2.waitKey(0)
			cv2.imshow("compare",combined)
			cv2.waitKey(0)


		unsortedanswers.append(totalvote)
		''' #Rotation Code WIP Doesnt work yet
		if (len(pcs_pts) >= 4):
			RotM = rotation(pcs_pts,full_pts)
			print RotM
			print RotM[0][0]
			print RotM[1][0]

			if (RotM[1][0]>1):
				RotM[1][0] = 1

			if (RotM[0][0]>1):
				RotM[0][0] = 1

			cosangle = np.degrees(np.arccos(RotM[0][0]))
			sinangle = np.degrees(np.arcsin(RotM[1][0]))

			print "cosangle is:" + str(cosangle)
			print "sinangle is:" + str(sinangle)

			Matrix = cv2.getRotationMatrix2D((size[0] / 2, size[1] / 2),(float(sinangle)),1)
			dst = cv2.warpAffine(croppedRotatedResized, Matrix, (int(croppedW), int(croppedH)))
			cv2.imshow('test', dst)
			cv2.waitKey(0)
		'''
	answithcpoints = np.column_stack([centerx, centery, unsortedanswers])
	sortedanswers = answithcpoints[answithcpoints[:, -1].argsort()]



	for ans in sortedanswers:
		cv2.putText(scatterpcs, str(ans[2]), (int(ans[0]),int(ans[1])), font, 1, (0, 0, 255), 3)
		
	print(sortedanswers)
	cv2.drawContours(scatterpcs,contours,-1,(0,0,255),2)

	cv2.imshow("scatter",scatterpcs)


	cv2.waitKey(0)
	cv2.destroyAllWindows()

	return sortedanswers #This is the array that will contain the answer

#answerarray = EntireImageRecognitionSection()