import numpy as np
#import matplotlib.pyplot as plt
import cv2


def imageRec(img1,img2):

    # Initiate SIFT detector
    sift = cv2.xfeatures2d.SIFT_create()

    # find the keypoints and descriptors with SIFT
    kp1, des1 = sift.detectAndCompute(img1,None)
    kp2, des2 = sift.detectAndCompute(img2,None)

    # BFMatcher with default params
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1,des2, k=2)
    # Apply ratio test
    good = []
    gooder = []
    for m,n in matches:
        if m.distance < 0.65*n.distance:
            good.append([m])
            gooder.append(m)

    pcs_pts = np.float32([kp1[m.queryIdx].pt for m in gooder])
    full_pts = np.float32([kp2[m.trainIdx].pt for m in gooder])

    if (pcs_pts.size == 0):
        print("no matches found")
        return img1,0,0,10
    else:
        print("pcs_pts")
        print(pcs_pts)
        print("full_pts")
        print(full_pts)

        height, width = img2.shape[:2]
        location =[]

        for m in full_pts:
            if m[0] < (width / 3): #0,3,6
                if m[1] < (height/3): #0
                    location.append(0)
                elif (m[1] > (height/3))and (m[1] < ((height/3)*2)): #3
                    location.append(3)
                elif m[1] > ((height/3)*2):#6
                    location.append(6)

            elif (m[0] > (width/3)) and (m[0] < ((width/3)*2)):#1,4,7
                if m[1] < (height/3): #1
                    location.append(1)
                elif (m[1] > (height/3))and (m[1] < ((height/3)*2)): #4
                    location.append(4)
                elif m[1] > ((height/3)*2): #7
                    location.append(7)

            elif m[0] > ((width/3)*2): #2,5,8
                if m[1] < (height / 3):  #2
                    location.append(2)
                elif (m[1] > (height / 3)) and (m[1] < ((height / 3) * 2)):  #5
                    location.append(5)
                elif m[1] > ((height / 3) * 2): #8
                    location.append(8)


        print(location)
        totalvote = max(location, key=location.count)
        #totalvote = 1
        #print totalvote

        ''' #Eliminates some of the wrong matches, might work, but not needed if not doing rotation
        for index,m in enumerate(location):
            print m
            if (m != totalvote):
                print("index: "+str(index))
                print("m: "+str(m))
                full_pts = np.delete(full_pts,index,0)
                pcs_pts = np.delete(pcs_pts,index,0)
        print location
        print full_pts
        print pcs_pts
        '''

        #cv2.drawMatchesKnn expects list of lists as matches.
        img3 = cv2.drawMatchesKnn(img1,kp1,img2,kp2,good,None,flags=2)
        return img3, pcs_pts, full_pts, totalvote



