import numpy as np
#import matplotlib.pyplot as plt
import cv2

centerx = []
centery = []


def findContours(img,min_threshold_area,max_threshold_area):
    filteredcontours = []
    blurred = cv2.GaussianBlur(img, (7, 7), 0)
    threshold = cv2.threshold(blurred, 40, 255, cv2.THRESH_BINARY)[1]

    kernel = np.ones((3, 3), np.uint8)
    closing = cv2.morphologyEx(threshold, cv2.MORPH_CLOSE, kernel, iterations=4)

    cv2.imshow('th',closing)
    cv2.waitKey(0)

    _,contours,_=cv2.findContours(closing,cv2.RETR_LIST,cv2.CHAIN_APPROX_NONE)
    #print "Number of countours:" %len(contours)

    cv2.drawContours(img,contours,-1,(0,0,255),3)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        print(area)
        if (area > min_threshold_area) and (area < max_threshold_area):
            #print area
            filteredcontours.append(cnt)

    cv2.imshow('img',img)
    cv2.waitKey(0)
    return filteredcontours


