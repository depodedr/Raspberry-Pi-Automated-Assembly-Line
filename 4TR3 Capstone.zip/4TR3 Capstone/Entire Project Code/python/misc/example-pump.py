#! /usr/bin/env python

from dobot import Dobot
from dobot import DobotDriver
import time

# dobot = Dobot('COM4', debug=True)
dobot = Dobot('/dev/ttyACM0', debug=True)
driver = DobotDriver('/dev/ttyACM0')
driver.Open()
successes = 0
i = 0
while True:
	ret = driver.isReady()
	if ret[0] and ret[1]:
		successes += 1
	if successes > 10:
		print("Dobot ready!")
		break
	if i > 100:
		raise Exception('Comm problem')


def repeatUntilQueued(on):
	ret = (0,0)
	while not ret[0] or not ret[1]:
		ret = dobot.PumpOn(on)
	ret = (0,0)
	while not ret[0] or not ret[1]:
		ret = dobot.ValveOn(on)

repeatUntilQueued(True)
time.sleep(10)
repeatUntilQueued(False)

