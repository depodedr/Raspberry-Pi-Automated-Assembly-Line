#! /usr/bin/env python

from dobot import Dobot
from dobot import DobotDriver
from dobot.DobotKinematics import *
from dobot.DobotPiIK import *
import time
import math
import sys

if sys.version_info > (3,):
	long = int

# dobot = Dobot('COM4', debug=True)
dobot = Dobot('/dev/ttyACM0', debug=True)
driver = DobotDriver('/dev/ttyACM0')
driver.Open()
successes = 0
i = 0
while True:
	ret = driver.isReady()
	if ret[0] and ret[1]:
		successes += 1
	if successes > 10:
		print("Dobot ready!")
		break
	if i > 100:
		raise Exception('Comm problem')

# The NEMA 17 stepper motors that Dobot uses are 200 steps per revolution.
stepperMotorStepsPerRevolution = 200.0
# FPGA board has all stepper drivers' stepping pins set to microstepping.
baseMicrosteppingMultiplier = 16.0
rearArmMicrosteppingMultiplier = 16.0
frontArmMicrosteppingMultiplier = 16.0
# The NEMA 17 stepper motors Dobot uses are connected to a planetary gearbox, the black cylinders
# with 10:1 reduction ratio
stepperPlanetaryGearBoxMultiplier = 10.0

# calculate the actual number of steps it takes for each stepper motor to rotate 360 degrees
baseActualStepsPerRevolution = stepperMotorStepsPerRevolution * baseMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier
rearArmActualStepsPerRevolution = stepperMotorStepsPerRevolution * rearArmMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier
frontArmActualStepsPerRevolution = stepperMotorStepsPerRevolution * frontArmMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier

# Coordinates for x,y,z
x = 100.0
y = 80.0
z = 20.0
dura = 1000.0

# Dimentions in mm
lengthRearArm = 135.0
lengthFrontArm = 160.0
# Horizontal distance from Joint3 to the center of the tool mounted on the end effector.
distanceTool = 50.9
# Joint1 height.
heightFromGround = 103.0

lengthRearSquared = pow(lengthRearArm, 2)
lengthFrontSquared = pow(lengthFrontArm, 2)

armSquaredConst = pow(lengthRearArm, 2) + pow(lengthFrontArm, 2)
armDoubledConst = 2.0 * lengthRearArm * lengthFrontArm
radiansToDegrees = 180.0 / math.pi
degreesToRadians = math.pi / 180.0

piHalf = math.pi / 2.0
piTwo = math.pi * 2.0
piThreeFourths = math.pi * 3.0 / 4.0
	    
def repeatUntilQueued(on):
	ret = (0,0)
	while not ret[0] or not ret[1]:
		ret = dobot.PumpOn(on)
	ret = (0,0)
	while not ret[0] or not ret[1]:
		ret = dobot.ValveOn(on)

def execute(keys1, keys2, keys3, direction1, direction2, direction3):
	for key1, key2, key3 in zip(keys1, keys2, keys3):
		code1 = driver.freqToCmdVal(key1)
		code2 = driver.freqToCmdVal(key2)
		code3 = driver.freqToCmdVal(key3)
		for i in range(0, 4):
			ret = (1, 0)
			# Check for return from Arduino to make sure the command was queued.
			# See function desciption for more details.
			while not ret[1]:
				ret = driver.Steps(code1, code2, code3, direction1, direction2, direction3, 0, 0)



test = DobotKinematics()
test2 = DobotPiIK()

result1,result2,result3 = test2.convert_cartesian_coordinate_to_arm_angles(x,y,z,lengthRearArm,lengthFrontArm,heightFromGround)
radresult1,radresult2, radresult3 = test.anglesFromCoordinates(x,y,z)

print(x, ', ', y, ', ', z)

degresult1 = radresult1*radiansToDegrees
degresult2 = radresult2*radiansToDegrees
degresult3 = radresult3*radiansToDegrees

print(degresult1, ', ',degresult2,', ',degresult3)
print(result1, ', ',result2,', ',result3)

#X_steps = degresult1 / (frontArmActualStepsPerRevolution / 360)
#Y_steps = degresult2 / (baseActualStepsPerRevolution / 360)
#Z_steps = degresult3 / (rearArmActualStepsPerRevolution / 360)

#dobot._moveArmToAngles(degresult1, degresult2, degresult3, dura)
#dobot._moveTo(x,y,z,dura)

#print(X_steps, ', ',Y_steps,', ',Z_steps)

#steps1 = driver.stepsToCmdVal(X_steps)
#steps2 = driver.stepsToCmdVal(Y_steps)
#steps3 = driver.stepsToCmdVal(Z_steps)

#print(steps1, ', ',steps2,', ',steps3)
"""
driver.SetCounters(0, 0, 0)
errors = 0
for i in range(20):
	ret = (0, 0)
	while not ret[1]:
		ret = driver.Steps(steps1, steps2, steps3, 1, 0, 1, 0, 0)"""
		
#increment = 0	
#while True:
    #dobot._moveTo(x, y, z, 100)
    #increment = increment + 1
    #test.moveArmToAngles(radresult1, radresult2, radresult3, dura)

time.sleep(3)

freq = [800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100]


freq2 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]


increasing = freq
decreasing = sorted(freq, reverse=True)
execute(increasing, [], increasing, 0, 0, 0)

while True:
    execute(freq2, decreasing, freq2, 0, 0, 0)
    time.sleep(2)
    repeatUntilQueued(True)
    time.sleep(2)
    execute(increasing, freq2, freq2, 1, 0, 0)
    repeatUntilQueued(False)
    time.sleep(2)
    execute(freq2, increasing, freq2, 0, 1, 0)
    execute(decreasing, freq2, freq2, 0, 0, 0)
    time.sleep(2)
