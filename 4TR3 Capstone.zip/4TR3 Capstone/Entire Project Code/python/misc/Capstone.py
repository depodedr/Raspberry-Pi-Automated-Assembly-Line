from dobot import Dobot
from dobot import DobotDriver
from dobot.DobotKinematics import *
from dobot.DobotPiIK import *
from dobot.DobotInverseKinematics import *
import cv2
import time
import math
import sys

if sys.version_info > (3,):
	long = int

# dobot = Dobot('COM4', debug=True)
dobot = Dobot('/dev/ttyACM0', debug=True)
driver = DobotDriver('/dev/ttyACM0')
driver.Open()
successes = 0
i = 0
while True:
	ret = driver.isReady()
	if ret[0] and ret[1]:
		successes += 1
	if successes > 10:
		print("Dobot ready!")
		break
	if i > 100:
		raise Exception('Comm problem')

# The NEMA 17 stepper motors that Dobot uses are 200 steps per revolution.
stepperMotorStepsPerRevolution = 200.0
# FPGA board has all stepper drivers' stepping pins set to microstepping.
baseMicrosteppingMultiplier = 16.0
rearArmMicrosteppingMultiplier = 16.0
frontArmMicrosteppingMultiplier = 16.0
# The NEMA 17 stepper motors Dobot uses are connected to a planetary gearbox, the black cylinders
# with 10:1 reduction ratio
stepperPlanetaryGearBoxMultiplier = 10.0

# calculate the actual number of steps it takes for each stepper motor to rotate 360 degrees
baseActualStepsPerRevolution = stepperMotorStepsPerRevolution * baseMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier
rearArmActualStepsPerRevolution = stepperMotorStepsPerRevolution * rearArmMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier
frontArmActualStepsPerRevolution = stepperMotorStepsPerRevolution * frontArmMicrosteppingMultiplier * stepperPlanetaryGearBoxMultiplier

# Coordinates for x,y,z
#x = 100.0
#y = 80.0
#z = 20.0
dura = 1000.0

# Dimentions in mm
lengthRearArm = 135.0
lengthFrontArm = 160.0
# Horizontal distance from Joint3 to the center of the tool mounted on the end effector.
distanceTool = 50.9
# Joint1 height.
heightFromGround = 80.0

lengthRearSquared = pow(lengthRearArm, 2)
lengthFrontSquared = pow(lengthFrontArm, 2)

armSquaredConst = pow(lengthRearArm, 2) + pow(lengthFrontArm, 2)
armDoubledConst = 2.0 * lengthRearArm * lengthFrontArm
radiansToDegrees = 180.0 / math.pi
degreesToRadians = math.pi / 180.0

piHalf = math.pi / 2.0
piTwo = math.pi * 2.0
piThreeFourths = math.pi * 3.0 / 4.0

jointAnglesOnALine = []

#stepperPositions holds the stepper motor step numbers at each point on a line. For example, a 200 step/rev
#stepper motor without microstepping might have a position of 10, which is 10 steps away from its starting position
#in some direction. -10 would be 10 steps in the opposite direction
stepperPositionsOnALine = []

#stepperSequenceToDrawALine holds the actual stepper sequence data for a line (specifies whether or not a stepper
#should move). see the readme on github
stepperSequenceToDrawALine = []
lastBaseDir = -2
lastUpperDir = -2
lastLowerDir = -2

#determines how many slices to slice up a linear movement path into. More slices means straighter and smoother
#lines. may increase processing time and/or number of steps to take.
linearLineResolution = 1000
PtoMM = 1.0 / 3.779527559
accelOffsets = (1024,1024)
DobotKin = DobotKinematics()
DobotIK = DobotPiIK()

def repeatUntilQueued(on):
    ret = (0,0)
    while not ret[0] or not ret[1]:
	    ret = dobot.PumpOn(on)
    ret = (0,0)
    while not ret[0] or not ret[1]:
	    ret = dobot.ValveOn(on)
	    
def execute(keys1, keys2, keys3, direction1, direction2, direction3, gripper, toolRotation):
	for key1, key2, key3 in zip(keys1, keys2, keys3):
		code1 = driver.freqToCmdVal(key1)
		code2 = driver.freqToCmdVal(key2)
		code3 = driver.freqToCmdVal(key3)
		for i in range(0, 4):
			ret = (1, 0)
			# Check for return from Arduino to make sure the command was queued.
			# See function desciption for more details.
			while not ret[1]:
				ret = driver.Steps(code1, code2, code3, direction1, direction2, direction3, gripper, toolRotation)
                                               
	    
class Capstone:
    driver = DobotDriver('/dev/ttyACM0')
    driver.Open()
    
    def __init__(self, debug=False):
        self._debugOn = debug
        self._toolRotation = 0
        self._gripper = 0
        
    def _debug(self, *args):
        if self._debugOn:
	# Since "print" is not a function the expansion (*) cannot be used
	# as it is not an operator. So this is a workaround.
            for arg in args:
                sys.stdout.write(str(arg))
                sys.stdout.write(' ')
                print('')
                
    def ToolRotation(self, toolRotation):
        if toolRotation > 1024:
            self._toolRotation = 1024
        elif toolRotation < 0:
            self._toolRotation = 0
        else:
            self._toolRotation = toolRotation
            
        serv = driver.Steps(0, 0, 0, 0, 0, 0, self._gripper, self._toolRotation)

        return serv   
    
    def InitializeAccelerometers(self):
        print("--=========--")
        print("Initializing accelerometers")
        if driver.isFpga():
            # In FPGA v1.0 SPI accelerometers are read only when Arduino boots. The readings
            # are already available, so read once.
            ret = (0, 0, 0, 0, 0, 0, 0)
            while not ret[0]:
                    ret = driver.GetAccelerometers()
            accelRearX = ret[1]
            accelFrontX = ret[4]
            rearAngle = piHalf - driver.accelToRadians(accelRearX, accelOffsets[0])
            frontAngle = driver.accelToRadians(accelFrontX, accelOffsets[1])
            
        self._baseSteps = long(0)
        self._rearSteps = long((rearAngle / piTwo) * rearArmActualStepsPerRevolution + 0.5)
        self._frontSteps = long((frontAngle / piTwo) * frontArmActualStepsPerRevolution + 0.5)
        driver.SetCounters(self._baseSteps, self._rearSteps, self._frontSteps)
        print("Initializing with steps:", self._baseSteps, self._rearSteps, self._frontSteps)
        print("Reading back what was set:", driver.GetCounters())
        currBaseAngle = piTwo * self._baseSteps / baseActualStepsPerRevolution
        currRearAngle = piHalf - piTwo * self._rearSteps / rearArmActualStepsPerRevolution
        currFrontAngle = piTwo * self._frontSteps / frontArmActualStepsPerRevolution
#        startXYZ = DobotIK.get_cartesian_coordinate_from_angles_using_forward_kinematics(currBaseAngle, currRearAngle, currFrontAngle)
        startXYZ = DobotIK.get_cartesian_coordinate_from_angles_using_forward_kinematics(0, 90, 0)
        print('Current estimated coordinates:', startXYZ)
        print(startXYZ)
        self.update_position_based_on_cartesian_coordinate(int(startXYZ[0]),int(startXYZ[1]),int(startXYZ[2]))
        print("--=========--")
            
    def MoveToCoordinate(self, moveToX, moveToY, moveToZ):
        # divide a line between starting and end points into many equally spaced points and move to each of those points,
        # so the arm moves in a straight line
        startingPointX = self.currentXPosition
        startingPointY = self.currentYPosition
        startingPointZ = self.currentZPosition
        
        print("START :\t%f\t%f\t%f" % (startingPointX , startingPointY, startingPointZ));
        
        
        moveToXFloat = float(moveToX)
        moveToYFloat = float(moveToY)
        moveToZFloat = float(moveToZ)
        
        print("MOVETO:\t%f\t%f\t%f" % (moveToXFloat, moveToYFloat, moveToZFloat));
        
        
        #vector directions for vector equation of line
        directionX = moveToXFloat - startingPointX 
        directionY = moveToYFloat - startingPointY
        directionZ = moveToZFloat - startingPointZ 
        #determines how many slices to slice up the line in
        linearMovementResolution = linearLineResolution

        #clear the stepper sequence for the line and the stepper positions on the line
        cartesianCoordinate = []
        jointAnglesOnALine[:] = []
        stepperPositionsOnALine[:] = []
        stepperSequenceToDrawALine[:] = []
        
        #iterate through the line slices (points on the line path for the arm to move along)
        #simulate moving to each sub point, using inverse kinematics in the move_to_cartesian_coordinate function
        #to return the corresponding angles to move to. within the move_to_cartesian function, the angles are sent
        #to another function to convert them to stepper positions. these are stored in the corresponding stepper position
        #variable referenced in the constructor of this class
        nextPointX = 0
        nextPointY = 0
        nextPointZ = 0
        for i in range(1, linearMovementResolution+1):
            nextPointX = startingPointX + (directionX * (i/linearMovementResolution))
            nextPointY = startingPointY + (directionY * (i/linearMovementResolution))
            nextPointZ = startingPointZ + (directionZ * (i/linearMovementResolution))
            cartesianCoordinate.append(nextPointX)
            cartesianCoordinate.append(nextPointY)
            cartesianCoordinate.append(nextPointZ)
            
            #get the stepper position of each sub point on the line
            self.move_to_cartesian_coordinate(nextPointX, nextPointY, nextPointZ)
        
        #since the move has been determined to be valid and will be executed, update the current position and angles
        self.update_position_based_on_cartesian_coordinate(nextPointX, nextPointY, nextPointZ)
        
        #from the list of stepper positions to move to, generate an actual step sequence. an algorithm is used
        #to take as evenly spaced steps as possible so that the movement is more linear
        self.generate_line_step_sequence()

        #move the motors
        self.move_stepper_motors_using_line_step_sequence()
        
        print("cartesianCoordinates" + str(len(cartesianCoordinate)/3.0))
        for i in range(0, len(cartesianCoordinate), 3):
            print("%f\t%f\t%f" % (cartesianCoordinate[i], cartesianCoordinate[i+1], cartesianCoordinate[i+2]))
            
        print("jointAngles" + str(len(jointAnglesOnALine)/3.0))
        for i in range(0, len(jointAnglesOnALine), 3):
            print("%f\t%f\t%f" % (jointAnglesOnALine[i], jointAnglesOnALine[i+1], jointAnglesOnALine[1+2]))
        
        print("stepperPositionOnALine" + str(len(stepperPositionsOnALine)/3.0))
        for i in range(0, len(stepperPositionsOnALine), 3):
            print("%f\t%f\t%f" % (stepperPositionsOnALine[i], stepperPositionsOnALine[i+1], stepperPositionsOnALine[1+2]))
        
        #print("stepperSequenceToDrawALine");
        #for i in range(1, len(stepperSequenceToDrawALine)-1, 6):
        #    print("%f\t%f\t%f\t%f\t%f\t%f" % (stepperSequenceToDrawALine[i], stepperSequenceToDrawALine[i+1], stepperSequenceToDrawALine[i+2], stepperSequenceToDrawALine[i+3], stepperSequenceToDrawALine[i+4], stepperSequenceToDrawALine[i+5]))
        
        
    #note, this function doesn't really move to a cartesian anymore. just generate a stepper position sequence for moving along a line to a cartestian coordinate
    def move_to_cartesian_coordinate(self, moveToXFloat, moveToYFloat, moveToZFloat):
        # call inverse kinematics function to convert from cartesian coordinates to angles for Dobot arm
        # moveToAngles is a list of angles (type float) with the following order: [base angle, upper arm angle, lower arm angle]
        # catch any errors
        
        moveToAngles = DobotIK.convert_cartesian_coordinate_to_arm_angles(moveToXFloat,moveToYFloat,moveToZFloat,
        lengthRearArm, lengthFrontArm, heightFromGround)

        #these next 4 lines of code transform angles returned from the inverse kinematics code to the correct axes that
        #I defined for the dobot.
        moveToUpperArmAngleFloat = moveToAngles[1]
        moveToLowerArmAngleFloat = moveToAngles[2]

        transformedUpperArmAngle = (90 - moveToUpperArmAngleFloat)
        #-90 different from c++ code, accounts for fact that arm starts at the c++ simulation's 90
        # note that this line is different from the similar line in the move angles function. Has to do with the inverse kinematics function
        # and the fact that the lower arm angle is calculated relative to the upper arm angle.
        transformedLowerArmAngle = 360 + (transformedUpperArmAngle - moveToLowerArmAngleFloat) - 90

        jointAnglesOnALine.append(moveToAngles[0])
        jointAnglesOnALine.append(transformedUpperArmAngle) 
        jointAnglesOnALine.append(transformedLowerArmAngle)
        
        #converts the angles to stepper positions and updates the corresponding self variable
        self.convert_angles_to_stepper_positions(moveToAngles[0],transformedUpperArmAngle,transformedLowerArmAngle)
    
    def convert_angles_to_stepper_positions(self, baseAngle,upperArmAngle,lowerArmAngle):

        baseStepNumber = int(( (abs(baseAngle)/360) * baseActualStepsPerRevolution ) + 0.5)
        #need this because of the abs value function, which is needed for proper rounding
        if (baseAngle < 0):
            baseStepNumber *= -1



        upperArmStepNumber = int(( (abs(upperArmAngle)/360) * rearArmActualStepsPerRevolution ) + 0.5)
        #need this because of the abs value function, which is needed for proper rounding
        if (upperArmAngle < 0):
            upperArmStepNumber *= -1


        lowerArmStepNumber = int(( (abs(lowerArmAngle)/360) * frontArmActualStepsPerRevolution ) + 0.5)
        #need this because of the abs value function, which is needed for proper rounding
        if (lowerArmAngle < 0):
            lowerArmStepNumber *= -1

        #necessary to reverse the direction in which the steppers move, so angles match my defined angles
        #WARNING - Only reversing these numbers signs does not change the stepper directions. errors will occur
        #change the direction values from 0 to 1 and vice versa in the generate_line_step_sequence function if you want
        #to change the stepper direction in the code. Alternatively, just switch the direction of the stepper plugs
        baseStepNumber *= -1
        upperArmStepNumber *= -1
        lowerArmStepNumber *= 1

        stepperPositionsOnALine.append(baseStepNumber)
        stepperPositionsOnALine.append(upperArmStepNumber)
        stepperPositionsOnALine.append(lowerArmStepNumber)

        debug = 0;
        if debug:
          print("Base Angle")
          print(baseAngle)
          print("Base Step Number")
          print(baseStepNumber)
          print("Upper Arm Angle")
          print(upperArmAngle)
          print("Upper Arm Step Number")
          print(upperArmStepNumber)
          print("Lower Arm Angle")
          print(lowerArmAngle)
          print("Lower Arm Step Number")
          print(lowerArmStepNumber)
         
    def move_stepper_motors_using_line_step_sequence(self):
        #debugs the stepper motor movement code below
        debug = 0

        if (debug):
            print("StepperSequenceToDrawALine");
            for i in range(0,len(stepperSequenceToDrawALine)):
                #print("start chunk")
                for j in range(1,len(stepperSequenceToDrawALine[i])-1,6):
                    print(stepperSequenceToDrawALine[i][j:j+6])
                #print("end chunk")
            print("StepperSequenceToDrawALine-DONE");

        #quick fix for moves to current coordinate. notices that no steps specified in first chunk, so exits
        if(len(stepperSequenceToDrawALine[1]) == 0):
            return

        stepsPer20msec = 40

        for i in range(1,len(stepperSequenceToDrawALine)-1):# note the 1 and -1 to exclude the 's' and 'e' chunks
#                print("start chunk")
                k = math.floor( (len(stepperSequenceToDrawALine[i])/6) / stepsPer20msec )
                leftOverStepsIn20msec = int((len(stepperSequenceToDrawALine[i])/6) % stepsPer20msec) #should always be an int unless step sequence did not generate 6-tuples or something else went wrong
                chunkBaseDir = stepperSequenceToDrawALine[i][0]
                chunkUpperDir = stepperSequenceToDrawALine[i][1]
                chunkLowerDir = stepperSequenceToDrawALine[i][2]
                for j in range(0,k):
#                    print("start window")
                    baseStepsIn20msecSlice = 0
                    upperArmStepsIn20msecSlice = 0
                    lowerArmStepsIn20msecSlice = 0
                    for a in range(0,stepsPer20msec):
                        tempIndexModifier = (j*(stepsPer20msec*6)) + (a*6)
                        baseStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+3]
                        upperArmStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+4]
                        lowerArmStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+5]
                    print(str(chunkBaseDir)+','+str(chunkUpperDir)+','+str(chunkLowerDir)+','+str(baseStepsIn20msecSlice)+','+str(upperArmStepsIn20msecSlice)+','+str(lowerArmStepsIn20msecSlice))
                    ret = (0, 0)
                    while not ret[1]:
                        ret = driver.Steps(driver.stepsToCmdVal(baseStepsIn20msecSlice),
                                                driver.stepsToCmdVal(upperArmStepsIn20msecSlice),
                                                driver.stepsToCmdVal(lowerArmStepsIn20msecSlice),
                                                chunkBaseDir, chunkUpperDir, chunkLowerDir,
                                                480, 0)
#                    print('end window')

#                print("start last window")
                baseStepsIn20msecSlice = 0
                upperArmStepsIn20msecSlice = 0
                lowerArmStepsIn20msecSlice = 0
                for a in range(0,leftOverStepsIn20msec):
                        tempIndexModifier = (k*(stepsPer20msec*6)) + (a*6)
                        baseStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+3]
                        upperArmStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+4]
                        lowerArmStepsIn20msecSlice += stepperSequenceToDrawALine[i][tempIndexModifier+5]
                print(str(baseStepsIn20msecSlice)+','+str(upperArmStepsIn20msecSlice)+','+str(lowerArmStepsIn20msecSlice))
                ret = (0, 0)
                while not ret[1]:
                    ret = driver.Steps(driver.stepsToCmdVal(baseStepsIn20msecSlice),
                                            driver.stepsToCmdVal(upperArmStepsIn20msecSlice),
                                            driver.stepsToCmdVal(lowerArmStepsIn20msecSlice),
                                            chunkBaseDir, chunkUpperDir, chunkLowerDir,
                                            480, 0)
#                print('end last window')

#                print("end chunk")

        #dictates how fast the stepper motor moves (by changing the "pulse width", look it up if you want to know what that means
        WaitTime = 0.001

        speed = 1 #3.47kHz
        
    #creates the line data as specified in the readme in the github repository
    def generate_line_step_sequence(self):
        
        #these variables keep track of each stepper motor's stepper position (see comments immediately above this one for
        # a description of stepper position)
        basePos = 0
        upperPos = 0
        lowerPos = 0

        stepperSequenceToDrawALine.append('s')
        #initialize step sequence
        stepperSequenceToDrawALine.append([])
        lastIndexStepperSequenceToDrawALine = 1

        #initialize variables to hold stepper directions
        baseDir = -1
        upperArmDir = -1
        lowerArmDir = -1

        #intialize the lastPos variables
        lastBaseDir = -2
        lastUpperDir = -2
        lastLowerDir = -2

        #generating the step sequences of a line from the step positions, NOTE the increment by 3
        for j in range(0,len(stepperPositionsOnALine),3):
            #base direction
            baseSteps = (stepperPositionsOnALine[j] - basePos)
            if(baseSteps > 0):
                baseDir = 1
            elif(baseSteps == 0):
                baseDir = lastBaseDir
            else:
                baseDir = 0
            #upper arm direction
            upperSteps = (stepperPositionsOnALine[j+1] - upperPos)
            if(upperSteps > 0):
                upperArmDir = 1
            elif(upperSteps == 0):
                upperArmDir = lastUpperDir
            else:
                upperArmDir = 0
            #lower arm direction
            lowerSteps = (stepperPositionsOnALine[j+2] - lowerPos)
            if(lowerSteps > 0):
                lowerArmDir  = 1
            elif(lowerSteps == 0):
                lowerArmDir = lastLowerDir
            else:
                lowerArmDir  = 0
            
            self.generate_step_sequence_from_position_to_position_simple(abs(baseSteps), abs(upperSteps), abs(lowerSteps), baseDir, upperArmDir, lowerArmDir)

            #updating each stepper's step position. necessary for the proper step sequence (with directions) to be generated correctly
            basePos = stepperPositionsOnALine[j]
            upperPos = stepperPositionsOnALine[j+1]
            lowerPos = stepperPositionsOnALine[j+2]

            #update the last stepper directions
            lastBaseDir = baseDir
            lastUpperDir = upperArmDir
            lastLowerDir = lowerArmDir

        stepperSequenceToDrawALine.append('e')

        debug = False
        if(debug):
            print('Stepper Sequence')
            print(stepperSequenceToDrawALine)

    def update_position_based_on_cartesian_coordinate(self, moveToXFloat, moveToYFloat, moveToZFloat):
        #don't need error checking here since I already know these are valid coordinates to use with inverse kinematics

        # call inverse kinematics function to convert from cartesian coordinates to angles for Dobot arm
        # moveToAngles is a list of angles (type float) with the following order: [base angle, upper arm angle, lower arm angle]
        moveToAngles = DobotIK.convert_cartesian_coordinate_to_arm_angles(moveToXFloat,moveToYFloat,moveToZFloat,
            lengthRearArm, lengthFrontArm, heightFromGround)

        #these next 4 lines of code transform angles returned from the inverse kinematics code to the correct axes that
        #I defined for the dobot.
        moveToUpperArmAngleFloat = moveToAngles[1]
        moveToLowerArmAngleFloat = moveToAngles[2]

        transformedUpperArmAngle = (90 - moveToUpperArmAngleFloat)
        #-90 different from c++ code, accounts for fact that arm starts at the c++ simulation's 90
        # note that this line is different from the similar line in the move angles function. Has to do with the inverse kinematics function
        # and the fact that the lower arm angle is calculated relative to the upper arm angle.
        transformedLowerArmAngle = 360 + (transformedUpperArmAngle - moveToLowerArmAngleFloat) - 90
        
        self.currentBaseAngle = moveToAngles[0]
        self.currentUpperArmAngle = moveToAngles[1]
        self.currentLowerArmAngle = moveToAngles[2]
    
        self.currentXPosition = moveToXFloat
        self.currentYPosition = moveToYFloat
        self.currentZPosition = moveToZFloat
        
    def generate_step_sequence_from_position_to_position_simple(self, numBaseSteps, numUpperArmSteps, numLowerArmSteps, baseDir, upperArmDir, lowerArmDir):
        
        lastIndexStepperSequenceToDrawALine = 1
        #of the 3 stepper motors determine which one requires the most steps
        max_steps = float(max(max(numBaseSteps, numUpperArmSteps), numLowerArmSteps))#needs to be float so the rounding in the divisions work

        if(max_steps == 0):
            return


        debugNumBaseStepsExpected = numBaseSteps
        debugNumUpperArmStepsExpected = numUpperArmSteps
        debugNumLowerArmStepsExpected = numLowerArmSteps
        debugcounterBase = 0
        debugcounterUpper = 0
        debugcounterLower = 0

        sliceStepperSequenceToDrawALine = []

        for i in range(0, int(max_steps)):
            #append the step directions. NOTE that this is INEFFICIENT (though might not matter) and CAN BE IMPROVED, but is simple and easy to implement for now.
            sliceStepperSequenceToDrawALine.append(baseDir)
            sliceStepperSequenceToDrawALine.append(upperArmDir)
            sliceStepperSequenceToDrawALine.append(lowerArmDir)


            #append the steps
            if (numBaseSteps != 0):
                sliceStepperSequenceToDrawALine.append(1)
                numBaseSteps -= 1
                debugcounterBase += 1
            else:
                sliceStepperSequenceToDrawALine.append(0)

            if (numUpperArmSteps != 0):
                sliceStepperSequenceToDrawALine.append(1)
                numUpperArmSteps -= 1
                debugcounterUpper += 1
            else:
                sliceStepperSequenceToDrawALine.append(0)

            if (numLowerArmSteps != 0):
                sliceStepperSequenceToDrawALine.append(1)
                numLowerArmSteps -= 1
                debugcounterLower += 1
            else:
                sliceStepperSequenceToDrawALine.append(0)

        #if direction of any of the stepper motors has changed, need to generate a new "chunk" step sequence, otherwise add latest slice to newest "chunk"
        if ( (baseDir != lastBaseDir and lastBaseDir != -2) or (upperArmDir != lastUpperDir and lastUpperDir != -2) or (lowerArmDir != lastLowerDir and lastLowerDir != -2) ):
            #make a new "chunk" step sequence with the new direction combination by adding the latest slice to the stepperSequenceToDrawALine array of step sequence "chunk" arrays
            self.stepperSequenceToDrawALine.append(sliceStepperSequenceToDrawALine)
            lastIndexStepperSequenceToDrawALine += 1
        else:
            #merge newest slice step sequence with existing same direction combination "chunk" step sequence
            stepperSequenceToDrawALine[lastIndexStepperSequenceToDrawALine] += sliceStepperSequenceToDrawALine
               
            
Capstone = Capstone()
   
Capstone.InitializeAccelerometers()

"""
print('================================================================')
print('Future Positions')
print(x,', ',y,' ,',z)

rad1, rad2, rad3 = DobotKin.anglesFromCoordinates(x,y,z)
print(rad1,', ',rad2,' ,',rad3)

degr1 = rad1 * radiansToDegrees
degr2 = rad2 * radiansToDegrees
degr3 = rad3 * radiansToDegrees

print(degr1,', ',degr2,' ,',degr3)

X_steps = degr1 * (frontArmActualStepsPerRevolution / 360)
Y_steps = degr2 * (baseActualStepsPerRevolution / 360)
Z_steps = degr3 * (rearArmActualStepsPerRevolution / 360)

print(X_steps, ', ',Y_steps,', ',Z_steps)

steps1 = driver.stepsToCmdVal(X_steps)
steps2 = driver.stepsToCmdVal(Y_steps)
steps3 = driver.stepsToCmdVal(Z_steps)

print(steps1, ', ',steps2,', ',steps3)
"""
freq = [800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100]


freq2 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]


increasing = freq
decreasing = sorted(freq, reverse=True)
execute(increasing, [], increasing, 0, 0, 0, 0, 0)

#print(Capstone.ToolRotation(256))

xpix = 0
ypix = 0

x = xpix*PtoMM
y = ypix*PtoMM
#Max Points (0,0,0) = 34 cm
#Max Points (0,+-10,0) = 32
#Min Points (220,0,270) = 3.5 cm
#Min Points (220,+-10,270) = 0
#Middle Points (265,0,20) = 16.5 cm

Capstone.MoveToCoordinate(0,0,40)


"""
#Piece 1:
Capstone.MoveToCoordinate(150, 70, 95)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

execute(increasing, freq2, freq2, 1, 0, 0)
execute(increasing, freq2, freq2, 1, 0, 0)
execute(increasing, freq2, freq2, 1, 0, 0)

execute(freq2, freq2, increasing, 0, 0, 1)
execute(freq2, increasing, increasing, 0, 1, 1)

Capstone.ToolRotation(512)
time.sleep(5)
repeatUntilQueued(False)

#Piece 2:

Capstone.MoveToCoordinate(180, 0, 95)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)


#Piece 3:

Capstone.MoveToCoordinate(20, 0, 50)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 4:

Capstone.MoveToCoordinate(60,30,40)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 5:

Capstone.MoveToCoordinate(100,-20 ,50)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 6:

Capstone.MoveToCoordinate(180,-80,115)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 7:

Capstone.MoveToCoordinate(185, 110, 136)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 8:

Capstone.MoveToCoordinate(150, 30, 60)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)

#Piece 9:

Capstone.MoveToCoordinate(260,50,95)
time.sleep(5)
repeatUntilQueued(True)

execute(freq2, freq2, increasing, 0, 0, 0)
execute(freq2, increasing, increasing, 0, 1, 0)
"""
