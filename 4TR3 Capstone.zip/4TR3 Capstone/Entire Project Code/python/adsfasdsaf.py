import cv2

sift = cv2.xfeatures2d.SIFT_create()