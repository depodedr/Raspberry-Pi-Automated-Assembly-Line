import numpy as np
import cv2

def rotation(coord1, coord2):
    rotM = cv2.estimateRigidTransform(coord1,coord2,fullAffine=False)
    return rotM