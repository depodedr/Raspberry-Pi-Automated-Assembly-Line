#!/usr/bin/python3
import time
import picamera


def takePhoto(waitT,imgName):
	with picamera.PiCamera() as camera:
		#Camera Settings
			
		camera.resolution = (1024, 1024)
		camera.brightness = 50
		camera.contrast = 90
		camera.saturation = 35
		camera.sharpness = 1
		camera.ISO = 100
		camera.rotation = 90
		
		camera.start_preview()
			# Camera warm-up time
		time.sleep(10)
		camera.capture('/home/pi/Desktop/python/photos/'+str(imgName))
		#camera.capture('/home/pi/Desktop/python/photos/hardcodedpcs.jpg')
		camera.stop_preview()
		return
            
