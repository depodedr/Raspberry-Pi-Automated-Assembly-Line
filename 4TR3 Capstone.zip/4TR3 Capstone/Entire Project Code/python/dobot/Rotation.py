import sys
import math

# Coordinates of Square 1
Z1 = [0,0]
Z2 = [2,0]
Z3 = [2,2]
Z4 = [0,2]

# Coordinates of Square 2
W1 = [0,0]
W2 = [((math.sqrt(8))/2),((math.sqrt(8))/2)]
W3 = [0,(math.sqrt(8))]
W4 = [[(((-1)*math.sqrt(8))/2),((math.sqrt(8))/2)]]

# Radius of points Z2 and W2 on the 2 squares
R1 = math.sqrt(math.pow(Z2[0],2)+math.pow(Z2[1],2))
R2 = math.sqrt(math.pow(W2[0],2)+math.pow(W2[1],2))

print(R1)
print(R2)

# The angles of Z2 and W2 on the 2 squares
Theta1 = math.atan2(Z2[1],Z2[0])
Theta2 = math.atan2(W2[1],W2[0])

# Conversion from radians to degrees
radiansToDegrees = 180.0 / math.pi

DegrTheta1 = radiansToDegrees * Theta1
DegrTheta2 = radiansToDegrees * Theta2

print(DegrTheta1)
print(DegrTheta2)

# The change in angles from square 1 to square 2
DeltaTheta = DegrTheta2 - DegrTheta1

print(DeltaTheta)