#!/usr/bin/python3
import time
import picamera

PtoMM = 1.0 / 3.779527559

with picamera.PiCamera() as camera:
    camera.resolution = (1024, 1024)
    camera.start_preview()
    # Camera warm-up time
    time.sleep(300)
    camera.capture('/home/pi/Desktop/image.jpg')
    camera.stop_preview()
