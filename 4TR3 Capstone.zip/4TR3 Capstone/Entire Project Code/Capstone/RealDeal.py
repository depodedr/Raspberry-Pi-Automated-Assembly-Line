import numpy as np
#import matplotlib.pyplot as plt
import cv2

from PerspectiveRotation import *
from ImageRec import *
from Contour import *
from RigidTranform import *



tl =[310, 329]
tr = [668, 318]
bl = [305, 698]
br = [685, 686]
font = cv2.FONT_HERSHEY_SIMPLEX

unsortedanswers =[]
'''
full = cv2.imread('C:/Users/Elliot-Switch12/PycharmProjects/Capstone/fullturtle.jpg')
fullgrey = cv2.cvtColor(full,cv2.COLOR_BGR2GRAY)
fullgrey = rotatePerspective(fullgrey,tl,tr,bl,br)
'''
# This automatically grabs the frame of the completed puzzle. output = fullgrey
full = cv2.imread('/home/pi/Desktop/python/photos/cutoff.jpg')
fullgrey = cv2.cvtColor(full,cv2.COLOR_BGR2GRAY)
fullcont = findContours(fullgrey,140000,160000)
print(fullcont[0])
rect = cv2.minAreaRect(fullcont[0])
box = cv2.boxPoints(rect)
fullgrey = rotatePerspective(fullgrey,box[1],box[2],box[0],box[3])
cv2.imshow("show",fullgrey)
cv2.waitKey(0)

scatterpcs = cv2.imread('/home/pi/Desktop/python/photos/pieces.JPG')
scatterpcsgrey = cv2.cvtColor(scatterpcs,cv2.COLOR_BGR2GRAY)

contours = findContours(scatterpcsgrey,14000,25000)

for index,cnt in enumerate(contours):

    print("piece # "+str(index))

    M = cv2.moments(cnt)
    cx = int(M['m10'] / M['m00'])
    centerx.append(cx)
    cy = int(M['m01'] / M['m00'])
    centery.append(cy)


    rect = cv2.minAreaRect(cnt)
    box = cv2.boxPoints(rect)
    box = np.int0(box)

    W = rect[1][0]
    H = rect[1][1]

    Xs = [i[0] for i in box]
    Ys = [i[1] for i in box]
    x1 = min(Xs)
    x2 = max(Xs)
    y1 = min(Ys)
    y2 = max(Ys)

    rotated = False
    angle = rect[2]
    print("the angle is:" + str(angle))

    if angle < -45:
        angle += 90
        print("the new angle is: " + str(angle))
        rotated = True

    center = (int((x1 + x2) / 2), int((y1 + y2) / 2))
    print("thecenter is: "+str(center)) #center of the entire of each page in the entire space
    size = (int(x2 - x1)), int((y2 - y1))

    M = cv2.getRotationMatrix2D((size[0] / 2, size[1] / 2), angle, 1.0)

    cropped = cv2.getRectSubPix(scatterpcsgrey, size, center)
    #cv2.imwrite("pieceC" + str(index) + ".jpg", cropped)

    croppedRotated = cv2.warpAffine(cropped, M, size)
    #cv2.imwrite("pieceCR" + str(index) + ".jpg", cropped)

    croppedW = W if not rotated else H
    croppedH = H if not rotated else W

    croppedRotatedResized = cv2.getRectSubPix(croppedRotated, (int(croppedW), int(croppedH)),
                                 (int(croppedW) / 2, int(croppedH) / 2))


    cv2.imwrite("pieceCRresize"+str(index)+".jpg",croppedRotatedResized)

    cv2.circle(scatterpcs, (cx, cy), 5, (0, 0, 255), 2)

    combined, pcs_pts, full_pts, totalvote = imageRec(cropped, fullgrey)
    cv2.imshow("compare",combined)
    cv2.waitKey(0)

    unsortedanswers.append(totalvote)
    '''
    if (len(pcs_pts) >= 4):
        RotM = rotation(pcs_pts,full_pts)
        print RotM
        print RotM[0][0]
        print RotM[1][0]

        if (RotM[1][0]>1):
            RotM[1][0] = 1

        if (RotM[0][0]>1):
            RotM[0][0] = 1

        cosangle = np.degrees(np.arccos(RotM[0][0]))
        sinangle = np.degrees(np.arcsin(RotM[1][0]))

        print "cosangle is:" + str(cosangle)
        print "sinangle is:" + str(sinangle)

        Matrix = cv2.getRotationMatrix2D((size[0] / 2, size[1] / 2),(float(sinangle)),1)
        dst = cv2.warpAffine(croppedRotatedResized, Matrix, (int(croppedW), int(croppedH)))
        cv2.imshow('test', dst)
        cv2.waitKey(0)
    '''
answithcpoints = np.column_stack([centerx, centery, unsortedanswers])
sortedanswers = answithcpoints[answithcpoints[:, -1].argsort()]

for ans in sortedanswers:
    cv2.putText(scatterpcs, str(ans[2]), (int(ans[0]),int(ans[1])), font, 1, (0, 0, 255), 3)

print(sortedanswers)
cv2.drawContours(scatterpcs,contours,-1,(0,0,255),2)

cv2.imshow("scatter",scatterpcs)


cv2.waitKey(0)
cv2.destroyAllWindows()