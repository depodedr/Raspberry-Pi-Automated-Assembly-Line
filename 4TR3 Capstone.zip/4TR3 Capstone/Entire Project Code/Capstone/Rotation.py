import sys
import numpy as np

def rotation(coord1, coord2, centerx, centery):
    # Coordinates of Square 1
    #Z2 = [2, 0]

    # Coordinates of Square 2
    #W2 = [((math.sqrt(8)) / 2), ((math.sqrt(8)) / 2)]


    # Radius of points Z2 and W2 on the 2 squares
    #R1 = math.sqrt(math.pow(Z2[0], 2) + math.pow(Z2[1], 2))
    R1 = np.sqrt(np.power((coord1[0]), 2) + np.power((-coord1[1]), 2))
    #R2 = math.sqrt(math.pow(W2[0], 2) + math.pow(W2[1], 2))
    R2 = np.sqrt(np.power((coord2[0]), 2) + np.power((-coord2[1]), 2))

    #print(R1)
    #print(R2)

    # The angles of Z2 and W2 on the 2 squares
    Theta1 = np.arctan2(coord1[1], coord1[0])
    Theta2 = np.arctan2(coord2[1], coord2[0])

    # Conversion from radians to degrees
    radiansToDegrees = 180.0 / np.pi

    DegrTheta1 = radiansToDegrees * Theta1
    DegrTheta2 = radiansToDegrees * Theta2

    print(DegrTheta1)
    print(DegrTheta2)

    # The change in angles from square 1 to square 2
    DeltaTheta = DegrTheta2 - DegrTheta1

    print(DeltaTheta)
    return DeltaTheta

