import numpy as np
import matplotlib.pyplot as plt
import cv2

from Contour import *
from ImageRec import *
from PerspectiveRotation import *
#from Rotation import *
from RotateSVD import *
from RigidTranform import *

pcs_pts =[]
full_pts =[]

tl =[120, 114]
tr = [810, 83]
bl = [84, 814]
br = [857, 817]





print box
