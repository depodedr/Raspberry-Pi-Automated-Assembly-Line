import numpy as np
import matplotlib.pyplot as plt
import cv2

from PerspectiveRotation import *

tl =[120, 114]
tr = [810, 83]
bl = [84, 814]
br = [857, 817]

full = cv2.imread('C:/Users/Elliot-Switch12/Desktop/Capstone Image Recognition/Picturesforthething/turtlewhole.jpg')
full = rotatePerspective(full,tl,tr,bl,br)
fullgrey = cv2.cvtColor(full,cv2.COLOR_BGR2GRAY)
pcs = cv2.imread('C:/Users/Elliot-Switch12/PycharmProjects/TestImageRec/piece8.JPG')
pcsgrey = cv2.cvtColor(pcs,cv2.COLOR_BGR2GRAY)

height, width = fullgrey.shape[:2]

print height, width