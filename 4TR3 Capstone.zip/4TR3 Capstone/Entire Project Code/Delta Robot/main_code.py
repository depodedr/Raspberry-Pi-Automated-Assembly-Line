import Slush
import time
import delta_kinematics as dk
import serial
arduinoSerialData = serial.Serial('/dev/ttyACM0', 9600)
num="2"
read=0
SlushBoard = Slush.sBoard()

arm1 = Slush.Motor(0)
arm2 = Slush.Motor(1)
arm3 = Slush.Motor(3)

#gearing parameters gernerated from delta design files
STEPSPERREV = 76800.0
STEPSPERDEG = 213.333333333

def calibrateDelta():
	
	arm1.resetDev()
	arm2.resetDev()
	arm3.resetDev()
	''' home all of the arms to there limit switches '''
	arm1.goUntilPress(0, 1, 1000)
	arm2.goUntilPress(0, 1, 1000)
	arm3.goUntilPress(0, 1, 1000)
	
	


	''' when each arm is finished send it to its zero position '''
	while arm1.isBusy():
		continue
	while arm2.isBusy():
		continue
	while arm3.isBusy():
		continue

	''' wait a bit and set the current positions as zero (required for InversKin) '''
	time.sleep(1)
	arm1.move(-8000)
	arm2.move(-8000)
	arm3.move(-8000)
	arm1.setAsHome()
	arm2.setAsHome()
	arm3.setAsHome()

def moveDelta(x, y, z):
	
	''' wait until nothing is busy '''
	while arm1.isBusy():
		continue
	while arm2.isBusy():
		continue
	while arm3.isBusy():
		continue

	''' calculate how far the arms have to move '''
	angles = dk.inverse(x, y, z)

	''' turn angles into number of steps'''
	dist1 = angles[1] * STEPSPERDEG
	dist2 = angles[2] * STEPSPERDEG
	dist3 = angles[3] * STEPSPERDEG

	''' set the step speed required '''

	''' send the motion commans '''
	arm1.goTo(round(dist1))
	arm2.goTo(round(dist2))
	arm3.goTo(round(dist3))

	return [dist1, dist2, dist3]

"""main function is here"""

def goHomeAll():
    
    arm1.goHome()
    arm2.goHome()
    arm3.goHome()
    
    return

def moveAll(x):
    
    arm1.move(x)
    arm2.move(x)
    arm3.move(x)
    
    return

def goConveyor():
    print (moveDelta(0, 0, -140))

    time.sleep(1)

##    arm1.move(-18000)
##    arm2.move(2000)
##    arm3.move(-8000)
    
    arm1.move(-18000)
    arm2.move(-500)
    arm3.move(-6500)

    time.sleep(2)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm2.move(-1300)
    
    time.sleep(0.25)

    arduinoSerialData.write(bytes(num.encode("ascii")))
    
    time.sleep(2)

##    arm1.move(2500)
##    arm2.move(3600)
##    arm3.move(3250)
    
    arduinoSerialData.write(bytes(num.encode("ascii")))

    time.sleep(1)
    
    print (moveDelta(0, 0, -140))
    
    time.sleep(2)

    goHomeAll()

    return

def goConveyor2():
    print (moveDelta(0, 0, -140))

    time.sleep(1)

    arm1.move(-19000)
    arm2.move(-500)
    arm3.move(-7500)

    time.sleep(2)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm1.move(-500)
    arm2.move(-500)
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm3.move(-500)
    
    time.sleep(0.25)
    
    arm2.move(-1500)
    
    time.sleep(0.25)

    arduinoSerialData.write(bytes(num.encode("ascii")))
    
    time.sleep(2)

##    arm1.move(2500)
##    arm2.move(3600)
##    arm3.move(3250)
    
    arduinoSerialData.write(bytes(num.encode("ascii")))

    time.sleep(1)
    
    print (moveDelta(0, 0, -140))
    
    time.sleep(2)

    goHomeAll()

    return

calibrateDelta()
time.sleep(1)
for x in range(1, 10):
    while(read != 1):
        read = int(arduinoSerialData.readline())
        if x < 7:
            goConveyor()
        elif x >= 7:
            goConveyor2()
    read=0
    arduinoSerialData.write(bytes(read))
    if x == 1:
        print (moveDelta(-54, -44, 95))
        time.sleep(1)
        print (moveDelta(-54, -44, 115))
        time.sleep(3)
        print (moveDelta(-54, -44, 95))
        time.sleep(1)
    elif x == 2:
        print (moveDelta(-39, -22, 100))
        time.sleep(1)
        print (moveDelta(-39, -22, 120))
        time.sleep(4)
        print (moveDelta(-39, -22, 100))
        time.sleep(1)
    elif x == 3:
        print (moveDelta(-28, -1, 100))
        time.sleep(1)
        print (moveDelta(-28, -1, 120))
        time.sleep(5)
        print (moveDelta(-28, -1, 100))
        time.sleep(1)
    elif x == 4:
        print (moveDelta(-33, -56, 100))
        time.sleep(1)
        print (moveDelta(-33, -56, 120))
        time.sleep(3)
        print (moveDelta(-33, -56, 100))
        time.sleep(1)
    elif x == 5:
        print (moveDelta(-22, -32, 100))
        time.sleep(1)
        print (moveDelta(-22, -32, 120))
        time.sleep(4)
        print (moveDelta(-22, -32, 100))
        time.sleep(1)
    elif x == 6:
        print (moveDelta(-9, -10, 100))
        time.sleep(1)
        print (moveDelta(-9, -10, 120))
        time.sleep(5)
        print (moveDelta(-9, -10, 100))
        time.sleep(1)
    ## Make other goConveyor for last 3 pieces 
    elif x == 7:
        print (moveDelta(4, -73, 110))
        time.sleep(1)
        print (moveDelta(-12, -63, 110))
        time.sleep(1)
        print (moveDelta(-12, -63, 130))
        time.sleep(3)
        print (moveDelta(-12, -63, 110))
        time.sleep(1)
    elif x == 8:
        print (moveDelta(15, -51, 110))
        time.sleep(1)
        print (moveDelta(-1, -41, 110))
        time.sleep(1)
        print (moveDelta(-1, -41, 130))
        time.sleep(4)
        print (moveDelta(-1, -41, 110))
        time.sleep(1)
    elif x == 9:        
        print (moveDelta(32, -19, 110))
        time.sleep(1)
        print (moveDelta(16, -19, 110))
        time.sleep(1)
        print (moveDelta(16, -19, 130))
        time.sleep(5)
        print (moveDelta(16, -19, 110))
        time.sleep(1)
    goHomeAll()
    time.sleep(1)

arm1.free()
arm2.free()
arm3.free()

