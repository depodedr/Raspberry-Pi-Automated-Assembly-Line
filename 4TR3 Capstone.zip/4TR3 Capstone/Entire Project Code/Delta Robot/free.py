import Slush
import time
import delta_kinematics as dk
import serial
arduinoSerialData = serial.Serial('/dev/ttyACM0', 9600)
num="2"
read=0
SlushBoard = Slush.sBoard()

arm1 = Slush.Motor(0)
arm2 = Slush.Motor(1)
arm3 = Slush.Motor(3)

#gearing parameters gernerated from delta design files
STEPSPERREV = 76800.0
STEPSPERDEG = 213.33333333

arduinoSerialData.write(bytes(num.encode("ascii")))



arm1.free()
arm2.free()
arm3.free()